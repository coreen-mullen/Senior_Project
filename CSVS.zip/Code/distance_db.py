import os
import pandas as pd
import numpy as np
from sklearn.cluster import DBSCAN

eps = 0.1 #user specified.
min_samples = 5

input_dir = "county_distance_matrices"
output_dir = "county_dbscan_labels"
os.makedirs(output_dir, exist_ok=True)

for filename in os.listdir(input_dir):
    if filename.endswith("_distance_matrix.csv"):
        county_name = filename.replace("_distance_matrix.csv", "").replace("_", " ")
        matrix_path = os.path.join(input_dir, filename)
        
        distance_matrix = pd.read_csv(matrix_path, header=None).values
        
        db = DBSCAN(eps=eps, min_samples=min_samples, metric='precomputed')
        labels = db.fit_predict(distance_matrix)
        
        labels_df = pd.DataFrame({'cluster_label': labels})
        output_filename = os.path.join(output_dir, f"{filename.replace('_distance_matrix.csv', '_dbscan_labels.csv')}")
        labels_df.to_csv(output_filename, index=False)
        
        print(f"Processed {county_name}: saved labels to {output_filename}")
