import pandas as pd
import numpy as np
import os

df1 = pd.read_csv('nc_accidents_2021.csv')
df2 = pd.read_csv('nc_accidents_2022.csv')

df = pd.concat([df1, df2], ignore_index=True)
df.reset_index(drop=True, inplace=True)

# gets euclidean distance.
def compute_distance(point1, point2):
    lat1, lon1 = point1
    lat2, lon2 = point2
    return np.sqrt((lat1 - lat2) ** 2 + (lon1 - lon2) ** 2)

# creates a distance matrix for each county.
def compute_distance_matrix_for_county(df_subset):
    n = len(df_subset)
    distance_matrix = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            point1 = (df_subset.iloc[i]['LATITUDE'], df_subset.iloc[i]['LONGITUD'])
            point2 = (df_subset.iloc[j]['LATITUDE'], df_subset.iloc[j]['LONGITUD'])
            distance_matrix[i, j] = compute_distance(point1, point2)
    return distance_matrix

counties = df['COUNTYNAME'].unique()

output_dir = "county_distance_matrices"
os.makedirs(output_dir, exist_ok=True)

for county in counties:
    df_county = df[df['COUNTYNAME'] == county].reset_index(drop=True)
    print(f"Computing distance matrix for {county}...")
    distance_matrix = compute_distance_matrix_for_county(df_county)
    
    safe_county = county.replace(" ", "_").replace("/", "_")
    filename = os.path.join(output_dir, f"{safe_county}_distance_matrix.csv")
    
    pd.DataFrame(distance_matrix).to_csv(filename, index=False, header=False)
    print(f"Saved distance matrix for {county} to {filename}")
