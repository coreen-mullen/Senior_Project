import pandas as pd
import numpy as np
from sklearn.cluster import KMeans, DBSCAN
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from scipy.stats import zscore

def load_and_filter_data(file_path, state_name='North Carolina'):
    df = pd.read_csv(file_path, encoding='ISO-8859-1')
   
    df.columns = df.columns.str.strip().str.upper()
    if 'STATENAME' not in df.columns:
        raise ValueError("STATENAME column not found in the dataset.")
    return df[df['STATENAME'].str.upper() == state_name.upper()]

def preprocess_for_clustering(df):
    cols = ['LATITUDE','LONGITUD','COUNTYNAME']
    df = df[[c for c in cols if c in df.columns]].dropna(subset=['LATITUDE','LONGITUD'])
    df.loc[:, 'LAT_Z'] = zscore(df['LATITUDE'])
    df.loc[:, 'LON_Z'] = zscore(df['LONGITUD'])

    return df[(df['LAT_Z'].abs()<=3)&(df['LON_Z'].abs()<=3)]

def apply_pca(df):
    coords = df[['LATITUDE','LONGITUD']]
    scaled = StandardScaler().fit_transform(coords)
    pcs = PCA(n_components=2).fit_transform(scaled)
    df['PCA1'], df['PCA2'] = pcs[:,0], pcs[:,1]
    return df, pcs

def elbow_method(data, title):
    inertias = []
    for k in range(2,10):
        inertias.append(KMeans(n_clusters=k, n_init=10, random_state=42).fit(data).inertia_)
    print(f"\nElbow method inertias for {title}: {inertias}")

def silhouette_analysis(data, title):
    scores = []
    for k in range(2,10):
        labels = KMeans(n_clusters=k, n_init=10, random_state=42).fit_predict(data)
        scores.append(silhouette_score(data, labels))
    best = 2 + int(np.argmax(scores))
    print(f"Silhouette scores for {title}: {scores}")
    print(f"Optimal K for {title}: {best}")
    return best

def run_clustering(df, pcs, title):
    elbow_method(pcs, title)
    k = silhouette_analysis(pcs, title)

    df['kmeans_cluster'] = KMeans(n_clusters=k, n_init=10, random_state=42).fit_predict(pcs)
    counts = df['kmeans_cluster'].value_counts()
    top = counts.max()
    hotspots = counts[counts==top].index.tolist()
    df['is_hotspot'] = df['kmeans_cluster'].isin(hotspots)

    db = DBSCAN(eps=0.3, min_samples=5).fit(pcs)
    df['dbscan_cluster'] = db.labels_
    if len(set(db.labels_))>1 and -1 not in set(db.labels_):
        score = silhouette_score(pcs, db.labels_)
        print(f"DBSCAN silhouette for {title}: {score:.3f}")
    else:
        print(f"DBSCAN failed for {title}") #error handling.
    return df

def summarize_pca(df, n=2):
    p = PCA(n_components=n).fit(df[['LATITUDE','LONGITUD']])
    var = p.explained_variance_ratio_.sum()*100
    print(f"PCA on raw coordinates explains {var:.2f}% variance with {n} components.")

def run_dbscan_summary(df):
    db = DBSCAN(eps=0.5, min_samples=5).fit(df[['LAT_Z','LON_Z']])
    labels = db.labels_
    ncl = len(set(labels)) - (1 if -1 in labels else 0)
    if ncl==0:
        print("DBSCAN (Z-space) found no clusters.")
    else:
        print(f"DBSCAN (Z-space) found {ncl} clusters.")

for year in ['2021','2022']:
    print(f"\n Processing {year} data...")
    path = f'nc_accidents_{year}.csv'
    df_raw = load_and_filter_data(path)
    df_clean = preprocess_for_clustering(df_raw)
    
    summarize_pca(df_clean)  
    run_dbscan_summary(df_clean) 
    
    df_pca, pcs = apply_pca(df_clean)
    df_result = run_clustering(df_pca, pcs, f"{year} Data")
    
    df_result.to_csv(f'nc_accident_analysis_{year}.csv', index=False)