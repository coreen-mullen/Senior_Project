import pandas as pd

def preprocess_accident_data(filepath):
    """
    Loads and preprocesses a FARS accident dataset, filtering for North Carolina (STATENAME)
    and selecting relevant columns only.

    Parameters:
        filepath (str): Path to the CSV file.

    Returns:
        pd.DataFrame: Cleaned and filtered accident data for North Carolina.
    """

    df = pd.read_csv(filepath, encoding='ISO-8859-1')

    df.columns = df.columns.str.strip().str.upper()

    if 'STATENAME' not in df.columns:
        raise ValueError(f"'STATENAME' column not found in {filepath}")
    
    df_nc = df[df['STATENAME'].str.strip().str.upper() == 'NORTH CAROLINA']

    #Columns we use
    columns_to_keep = [
        'STATENAME', 'ST_CASE', 'LATITUDE', 'LONGITUD', 'MONTH', 'DAY', 'YEAR',
        'HOUR', 'MINUTE', 'DAY_WEEKNAME', 'COUNTYNAME', 'CITYNAME', 'WEATHER', 'WEATHERNAME',
        'MAN_COLL', 'MAN_COLLNAME', 'LGT_COND', 'LGT_CONDNAME', 'FATALS', 'VE_TOTAL', 'PERSONS'
    ]

    columns_available = [col for col in columns_to_keep if col in df_nc.columns]
    df_nc = df_nc[columns_available]

    df_nc.dropna(subset=['LATITUDE', 'LONGITUD'], inplace=True)

    df_nc.reset_index(drop=True, inplace=True)

    return df_nc

data_2022 = preprocess_accident_data('accident.csv')
data_2021 = preprocess_accident_data('accident.csv')

data_2022.to_csv('nc_accidents_2022.csv', index=False)
data_2021.to_csv('nc_accidents_2021.csv', index=False)
