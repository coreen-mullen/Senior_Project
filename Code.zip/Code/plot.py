import pandas as pd
import os
import plotly.express as px
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
from scipy.stats import zscore

file_2022 = 'nc_accidents_2022.csv'
file_2021 = 'nc_accidents_2021.csv'

output_folder = 'accident_analysis_html_maps'
os.makedirs(output_folder, exist_ok=True)

df_2022 = pd.read_csv(file_2022, encoding='ISO-8859-1')
df_2021 = pd.read_csv(file_2021, encoding='ISO-8859-1')

def preprocess_data(df, year_label):
    df['LATITUDE'] = pd.to_numeric(df['LATITUDE'], errors='coerce')
    df['LONGITUD'] = pd.to_numeric(df['LONGITUD'], errors='coerce')
    df.dropna(subset=['LATITUDE', 'LONGITUD'], inplace=True)
    df = df[df['STATENAME'] == 'North Carolina'].copy()
    df['LAT_Z'] = zscore(df['LATITUDE'])
    df['LON_Z'] = zscore(df['LONGITUD'])
    df = df[(df['LAT_Z'].abs() <= 3) & (df['LON_Z'].abs() <= 3)]
    df['YEAR_SOURCE'] = year_label
    return df

df_nc_2022 = preprocess_data(df_2022, '2022')
df_nc_2021 = preprocess_data(df_2021, '2021')

scaler = StandardScaler()
combined_coords = pd.concat([
    df_nc_2022[['LATITUDE', 'LONGITUD']],
    df_nc_2021[['LATITUDE', 'LONGITUD']]
])
scaler.fit(combined_coords)

for df in [df_nc_2022, df_nc_2021]:
    coords_scaled = scaler.transform(df[['LATITUDE', 'LONGITUD']])
    db = DBSCAN(eps=0.25, min_samples=5)
    df['DBSCAN_Cluster'] = db.fit_predict(coords_scaled)


df_combined = pd.concat([df_nc_2022, df_nc_2021], ignore_index=True)

color_map = {'2021': 'purple', '2022': 'green'}

#make html maps for each county using plotly.
for county in df_combined['COUNTYNAME'].dropna().unique():
    try:
        df_county = df_combined[df_combined['COUNTYNAME'] == county]

        fig = px.scatter_mapbox(
            df_county,
            lat="LATITUDE",
            lon="LONGITUD",
            color="YEAR_SOURCE",
            title=f"Accident Hotspots in {county} County (2021 & 2022)",
            hover_data=['CITYNAME', 'YEAR', 'WEATHERNAME', 'VE_TOTAL', 'FATALS', 'DBSCAN_Cluster'],
            mapbox_style="open-street-map",
            zoom=9,
            center={
                'lat': df_county['LATITUDE'].mean(),
                'lon': df_county['LONGITUD'].mean()
            },
            color_discrete_map=color_map
        )

        fig.update_traces(marker=dict(size=9)) 

        fig.update_layout(margin={"r":0,"t":40,"l":0,"b":0})

        file_name = f'county_map_combined_{county}.html'
        file_path = os.path.join(output_folder, file_name)
        fig.write_html(file_path)

        print(f"Saved: {file_path}")

    except Exception as e:
        print(f"Skipped {county} due to error: {e}")
